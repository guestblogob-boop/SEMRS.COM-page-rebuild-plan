=== SEMRS ===
Contributors: semrs
Requires at least: 6.5
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.1.0
License: GPLv2 or later

Free, lightweight, SEO-first and AdSense-ready theme for agencies, tool sites and blogs. SEMRS Pro (plugin) adds premium modules.

== Description ==

Speed
* One stylesheet and one ~2 KB deferred script. No jQuery, no icon fonts, no web fonts by default (system fonts; optional self-hosted Inter).
* Core block CSS loads only for the blocks a page uses. Emoji, oEmbed discovery, jQuery Migrate and dashicons (for visitors) are removed.
* Featured image on single posts loads with fetchpriority="high" (LCP); others lazy-load.
* Customizer CSS is printed only for settings you change.

SEO
* Clean semantic HTML5: one H1 per page, landmarks, skip link, breadcrumbs (SEMRS Core SEO or Rank Math).
* Previous/next post links, back-to-top button. Pro: table of contents, progress bar, "Updated on" date, author box, related posts.
* Numbered pagination (no infinite scroll, which hurts crawling and ad viewability).

AdSense ready
* Styled, labelled, height-reserved ad spots for the SEMRS Core Ads module. Unfilled AdSense units collapse.
* Sticky sidebar for a high-viewability sidebar ad. Theme hooks for any ad network.

Design & layout
* Logo width controls for desktop and mobile (512 × 512 px recommended; square logos detected automatically) and adjustable header height, with live preview.
* Footer social icons for 9 networks in brand colours (or one colour), adjustable size.
* 3 section patterns (Hero, FAQ, CTA band) plus section components; SEMRS Pro adds 5 more.
* Menu item descriptions and a header button. Pro: sticky/transparent header and mega menu.
* Right / left / no sidebar per posts, pages and archives, plus a per-page override. Card grid or list archives.
* Templates: Full width (landing/service pages) and Blank canvas (no header/footer).
* Up to 4 footer widget columns, footer menu, copyright with {year}/{site}, disclaimer line, back-to-top button.
* Colour, font, font size and container width controls. WCAG AA default colours. Responsive at 544 / 921 / 1200 px.

Hooks
wp_body_open, semrs_before_header, semrs_header_actions, semrs_after_header, semrs_before_content, semrs_content_top, semrs_before_entry_content, semrs_after_entry_content, semrs_after_entry, semrs_content_bottom, semrs_sidebar_top, semrs_sidebar_bottom, semrs_after_content, semrs_before_footer, semrs_footer_bottom, semrs_after_footer, semrs_404_after. Filter: semrs_theme_layout.

== Changelog ==

= 1.1.0 =
* Automatic update notices from semrs.com (WordPress 'Update available' + one-click update)
* Logo width controls for desktop and mobile; 512×512 square logos detected automatically
* Footer social icons in brand colours (9 networks)
* Free/Pro split: premium modules moved to the SEMRS Pro plugin
* Pro: license status checked with semrs.com

= 1.0.0 =
* First release.
