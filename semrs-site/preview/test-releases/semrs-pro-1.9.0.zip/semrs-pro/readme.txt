=== SEMRS Pro ===
Contributors: semrs
Requires at least: 6.5
Tested up to: 6.8
Requires PHP: 7.4
Requires Plugins: semrs-core
Stable tag: 1.1.0
License: GPLv2 or later

Premium add-on for the free SEMRS theme and the free SEMRS Core plugin. Every module can be switched off under SEMRS → Modules.

== Theme Pro (needs the SEMRS theme) ==
* Sticky header and transparent front-page header.
* Mega menu: add the CSS class "semrs-mega" to a top menu item (2–4 columns).
* Table of contents (posts with 3+ headings), reading progress bar, "Updated on" date.
* Author box with "Reviewed by" line (custom field semrs_reviewed_by), related posts.
* 5 extra section patterns: service cards, 6-step process, pricing, tool section, contact section.
* White label: rename the theme in Appearance → Themes.

== SEO Pro ==
* Redirects: 301/302/307/410, wildcards, loop protection, 404 log with one-click redirect, Rank Math redirect import.
* Local SEO (multi-location): Locations with NAP, opening hours, map link, service areas and Google Business Profile link; LocalBusiness schema per location joined to the site graph; [semrs_locations] and [semrs_location id="…"] shortcodes.
* IndexNow: instant notification to Bing, Yandex, Seznam, Naver and others on publish, update and delete (paused on local/staging sites).
* Image SEO: alt text and titles from clean file names on upload (camera names ignored); missing alt attributes filled on output.

== Ads Manager ==
* Policy-safe AdSense and ad network placement with default exclusions, safe in-content insertion, density caps, device targeting, lazy loading, ads.txt and an admin-bar status.

== Site Layouts, Proof, Leads ==
* Site Layouts: block content at any theme position with display rules.
* Case Studies, Portfolio and Testimonials with permission gates.
* Contact Form 7 → GA4 generate_lead → thank-you page.

== License ==
SEMRS → License stores your key. Updates come from semrs.com (SEMRS Update Server): with a valid key, WordPress shows "Update available" and installs new versions in one click. Features never switch off when a license expires; the license controls updates and support.

== Changelog ==

= 1.1.0 =
* Automatic update notices from semrs.com (WordPress 'Update available' + one-click update)
* Logo width controls for desktop and mobile; 512×512 square logos detected automatically
* Footer social icons in brand colours (9 networks)
* Free/Pro split: premium modules moved to the SEMRS Pro plugin
* Pro: license status checked with semrs.com

= 1.0.0 =
* First release: Theme Pro, Redirects, Local SEO, IndexNow, Image SEO, Ads Manager, Site Layouts, Proof, Leads, License screen.
