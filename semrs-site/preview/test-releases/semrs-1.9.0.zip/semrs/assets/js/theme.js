/* SEMRS theme: mobile menu, submenu toggles, back to top. No dependencies. */
(function () {
	'use strict';
	var d = document, body = d.body;

	// Mobile menu.
	var toggle = d.querySelector('.menu-toggle');
	var nav = d.getElementById('site-navigation');
	if (toggle && nav) {
		toggle.addEventListener('click', function () {
			var open = nav.classList.toggle('is-open');
			toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
		});
		d.addEventListener('keydown', function (e) {
			if (e.key === 'Escape' && nav.classList.contains('is-open')) {
				nav.classList.remove('is-open');
				toggle.setAttribute('aria-expanded', 'false');
				toggle.focus();
			}
		});
		// Submenu toggle buttons (used below 922px).
		nav.querySelectorAll('.menu-item-has-children > a').forEach(function (link) {
			var sub = link.parentNode.querySelector('.sub-menu');
			if (!sub) { return; }
			var btn = d.createElement('button');
			btn.type = 'button';
			btn.className = 'sp-submenu-toggle';
			btn.setAttribute('aria-expanded', 'false');
			btn.setAttribute('aria-label', (link.textContent || '').trim() + ' submenu');
			btn.addEventListener('click', function () {
				var open = sub.classList.toggle('is-open');
				btn.setAttribute('aria-expanded', open ? 'true' : 'false');
			});
			link.insertAdjacentElement('afterend', btn);
		});
	}

	// Back to top (sticky header and progress bar live in SEMRS Pro).
	var top = d.querySelector('.sp-to-top');
	if (top) {
		var ticking = false;
		window.addEventListener('scroll', function () {
			if (!ticking) { ticking = true; window.requestAnimationFrame(function () { top.hidden = window.pageYOffset < 600; ticking = false; }); }
		}, { passive: true });
		top.addEventListener('click', function () {
			window.scrollTo({ top: 0, behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth' });
		});
	}
})();
