<?php
/**
 * SEMRS → License. Stores the key and exposes `semrs_pro_license_status`
 * for a licensing service (Freemius, Easy Digital Downloads Software
 * Licensing, Lemon Squeezy…) to plug into. No remote calls are made here.
 *
 * @package semrs-pro
 */

defined( 'ABSPATH' ) || exit;

/**
 * Menu.
 */
function semrs_pro_license_menu() {
	add_submenu_page( 'semrs', __( 'SEMRS Pro License', 'semrs-pro' ), __( 'License', 'semrs-pro' ), 'manage_options', 'semrs-license', 'semrs_pro_license_page' );
}
add_action( 'admin_menu', 'semrs_pro_license_menu', 90 );

/**
 * Setting.
 */
function semrs_pro_license_setting() {
	register_setting(
		'semrs_pro_license',
		'semrs_pro_license_key',
		array(
			'type'              => 'string',
			'sanitize_callback' => function ( $v ) {
				return preg_replace( '/[^A-Za-z0-9-]/', '', (string) $v );
			},
		)
	);
}
add_action( 'admin_init', 'semrs_pro_license_setting' );
add_action(
	'update_option_semrs_pro_license_key',
	function () {
		delete_option( 'semrs_pro_license_remote' );
		delete_site_transient( 'semrs_upd_' . md5( 'semrs-pro' ) );
	}
);

/**
 * License status. A licensing integration hooks this filter and returns
 * 'valid', 'expired' or 'invalid' after checking the key remotely.
 *
 * @return string
 */
function semrs_pro_license_status() {
	$key = (string) get_option( 'semrs_pro_license_key', '' );
	$status = '' === $key ? 'missing' : 'unverified';
	$remote = (string) get_option( 'semrs_pro_license_remote', '' );
	if ( '' !== $key && in_array( $remote, array( 'valid', 'expired', 'invalid', 'limit' ), true ) ) {
		$status = $remote; // Reported by the semrs.com update server.
	}
	return (string) apply_filters( 'semrs_pro_license_status', $status, $key );
}

/**
 * Page.
 */
function semrs_pro_license_page() {
	$status = semrs_pro_license_status();
	$labels = array(
		'missing'    => __( 'No license key entered.', 'semrs-pro' ),
		'unverified' => __( 'Key saved. It is checked with semrs.com at the next update check (Dashboard → Updates → Check again).', 'semrs-pro' ),
		'valid'      => __( 'License active: updates and support enabled.', 'semrs-pro' ),
		'expired'    => __( 'License expired: features keep working; renew for updates and support.', 'semrs-pro' ),
		'invalid'    => __( 'This key is not valid.', 'semrs-pro' ),
		'limit'      => __( 'This key is already active on its maximum number of sites.', 'semrs-pro' ),
	);
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'SEMRS Pro License', 'semrs-pro' ); ?></h1>
		<p><?php echo esc_html( isset( $labels[ $status ] ) ? $labels[ $status ] : $status ); ?></p>
		<form method="post" action="options.php">
			<?php settings_fields( 'semrs_pro_license' ); ?>
			<input type="text" class="regular-text code" name="semrs_pro_license_key" value="<?php echo esc_attr( get_option( 'semrs_pro_license_key', '' ) ); ?>" placeholder="XXXX-XXXX-XXXX-XXXX" autocomplete="off">
			<?php submit_button( __( 'Save key', 'semrs-pro' ) ); ?>
		</form>
		<p class="description"><?php esc_html_e( 'Pro features never switch off when a license expires; the license controls updates and support.', 'semrs-pro' ); ?></p>
	</div>
	<?php
}
