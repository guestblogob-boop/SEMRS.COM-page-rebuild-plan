<?php
/**
 * Free blog features: previous/next post links and back-to-top button.
 *
 * SEMRS Pro adds the table of contents, reading progress bar, "Updated on"
 * date, author box and related posts through the theme hooks.
 *
 * @package semrs
 */

defined( 'ABSPATH' ) || exit;

/**
 * Previous / next links.
 */
function semrs_theme_post_nav() {
	if ( is_singular( 'post' ) && semrs_theme_opt( 'post_nav' ) ) {
		the_post_navigation(
			array(
				'prev_text' => '<span class="meta-nav">' . esc_html__( 'Previous', 'semrs' ) . '</span> %title',
				'next_text' => '<span class="meta-nav">' . esc_html__( 'Next', 'semrs' ) . '</span> %title',
			)
		);
	}
}
add_action( 'semrs_after_entry', 'semrs_theme_post_nav', 10 );

/**
 * Back-to-top button.
 */
function semrs_theme_to_top() {
	if ( semrs_theme_opt( 'to_top' ) ) {
		echo '<button type="button" class="sp-to-top" aria-label="' . esc_attr__( 'Back to top', 'semrs' ) . '" hidden><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 4l-7 7 1.4 1.4L11 7.8V20h2V7.8l4.6 4.6L19 11z"/></svg></button>';
	}
}
add_action( 'wp_footer', 'semrs_theme_to_top', 5 );
