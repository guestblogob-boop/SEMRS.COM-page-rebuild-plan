<?php
/**
 * SEMRS top-level admin menu and module switches.
 *
 * @package semrs-core
 */

defined( 'ABSPATH' ) || exit;

/**
 * Top-level menu.
 */
function semrs_core_admin_menu() {
	add_menu_page( __( 'SEMRS', 'semrs-core' ), __( 'SEMRS', 'semrs-core' ), 'manage_options', 'semrs', 'semrs_core_render_dashboard', 'dashicons-chart-area', 58 );
	add_submenu_page( 'semrs', __( 'SEMRS Modules', 'semrs-core' ), __( 'Modules', 'semrs-core' ), 'manage_options', 'semrs', 'semrs_core_render_dashboard' );
}
add_action( 'admin_menu', 'semrs_core_admin_menu', 9 );

/**
 * Register the modules option.
 */
function semrs_core_register_modules_setting() {
	register_setting(
		'semrs_core_modules',
		'semrs_core_modules',
		array(
			'sanitize_callback' => function ( $in ) {
				$out = array();
				foreach ( array_keys( semrs_core_modules() ) as $key ) {
					$out[ $key ] = ! empty( $in[ $key ] );
				}
				return $out;
			},
		)
	);
}
add_action( 'admin_init', 'semrs_core_register_modules_setting' );

/**
 * Re-flush rewrites after modules change (sitemaps, post types).
 */
add_action(
	'update_option_semrs_core_modules',
	function () {
		update_option( 'semrs_core_flush', 1 );
	}
);
add_action(
	'init',
	function () {
		if ( get_option( 'semrs_core_flush' ) ) {
			delete_option( 'semrs_core_flush' );
			flush_rewrite_rules();
		}
	},
	99
);

/**
 * Dashboard page.
 */
function semrs_core_render_dashboard() {
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'SEMRS Core', 'semrs-core' ); ?> <small>v<?php echo esc_html( SEMRS_CORE_VERSION ); ?></small></h1>
		<p><?php esc_html_e( 'Switch modules on or off. A switched-off module loads no code at all.', 'semrs-core' ); ?></p>
		<form method="post" action="options.php">
			<?php settings_fields( 'semrs_core_modules' ); ?>
			<table class="widefat striped" style="max-width:900px">
				<tbody>
				<?php foreach ( semrs_core_modules() as $key => $m ) : ?>
					<tr>
						<td style="width:40px"><input type="checkbox" id="semrs-mod-<?php echo esc_attr( $key ); ?>" name="semrs_core_modules[<?php echo esc_attr( $key ); ?>]" value="1" <?php checked( semrs_core_module_on( $key ) ); ?>></td>
						<td><label for="semrs-mod-<?php echo esc_attr( $key ); ?>"><strong><?php echo esc_html( $m[0] ); ?></strong></label> <?php echo ( isset( $m[2] ) && 'pro' === $m[2] ) ? '<span style="background:#0b1f3a;color:#fff;border-radius:3px;padding:1px 6px;font-size:11px">PRO</span>' : ''; ?><br><span class="description"><?php echo esc_html( $m[1] ); ?></span></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
			<?php submit_button(); ?>
		</form>
		<?php if ( ! defined( 'SEMRS_PRO_VERSION' ) ) : ?>
			<div class="notice notice-info inline"><p><strong><?php esc_html_e( 'SEMRS Pro', 'semrs-core' ); ?></strong> <?php esc_html_e( 'adds redirects and a 404 log, multi-location local SEO, IndexNow, image SEO, an ads manager, site layouts (custom hooks), case studies and portfolio, lead tracking, a sticky header, mega menu, table of contents, author box, related posts and more section patterns.', 'semrs-core' ); ?></p></div>
		<?php endif; ?>
		<?php if ( function_exists( 'semrs_seo_conflict' ) && semrs_seo_conflict() ) : ?>
			<div class="notice notice-warning inline"><p>
				<?php
				/* translators: %s: plugin name */
				printf( esc_html__( '%s is active, so SEMRS SEO output is paused to avoid duplicate tags. Your existing titles and descriptions are read automatically. When ready: deactivate it, then check a few pages with View Source.', 'semrs-core' ), esc_html( semrs_seo_conflict() ) );
				?>
			</p></div>
		<?php endif; ?>
	</div>
	<?php
}
