<?php
/**
 * Theme Pro: premium features for the SEMRS theme.
 * Sticky/transparent header, mega menu, table of contents, reading progress,
 * "Updated on" date, author box with reviewer, related posts, extra
 * patterns, white label. Runs only when the SEMRS theme (or a child) is active.
 *
 * @package semrs-pro
 */

defined( 'ABSPATH' ) || exit;

if ( 'semrs' !== get_template() ) {
	return;
}

/**
 * Pro settings inside the theme's Customizer panel.
 *
 * @param array $map Theme settings.
 * @return array
 */
function semrs_pro_theme_settings( $map ) {
	return array_merge(
		$map,
		array(
			'sticky_header'     => array( 'header', 'checkbox', __( 'Sticky header (Pro)', 'semrs-pro' ), true ),
			'transparent_front' => array( 'header', 'checkbox', __( 'Transparent header on the front page (Pro)', 'semrs-pro' ), false ),
			'toc'               => array( 'blog', 'checkbox', __( 'Table of contents on posts, 3+ headings (Pro)', 'semrs-pro' ), true ),
			'progress'          => array( 'blog', 'checkbox', __( 'Reading progress bar (Pro)', 'semrs-pro' ), true ),
			'updated_date'      => array( 'blog', 'checkbox', __( 'Show "Updated on" date (Pro)', 'semrs-pro' ), true ),
			'author_box'        => array( 'blog', 'checkbox', __( 'Author box (Pro)', 'semrs-pro' ), true ),
			'related'           => array( 'blog', 'checkbox', __( 'Related posts (Pro)', 'semrs-pro' ), true ),
			'white_label'       => array( 'footer', 'text', __( 'White label: theme name shown in Appearance → Themes (Pro)', 'semrs-pro' ), '' ),
		)
	);
}
add_filter( 'semrs_theme_settings', 'semrs_pro_theme_settings' );

/**
 * Read a theme option (works before the theme's helper exists).
 *
 * @param string $key Key.
 * @return mixed
 */
function semrs_pro_opt( $key ) {
	return function_exists( 'semrs_theme_opt' ) ? semrs_theme_opt( $key ) : get_theme_mod( 'semrs_theme_' . $key );
}

/**
 * Styles and script for the Pro modules.
 */
function semrs_pro_theme_assets() {
	wp_enqueue_style( 'semrs-pro', SEMRS_PRO_URL . 'assets/pro.css', array( 'semrs' ), SEMRS_PRO_VERSION );
	wp_enqueue_script( 'semrs-pro', SEMRS_PRO_URL . 'assets/pro.js', array(), SEMRS_PRO_VERSION, array( 'in_footer' => true, 'strategy' => 'defer' ) );
}
add_action( 'wp_enqueue_scripts', 'semrs_pro_theme_assets', 15 );

/**
 * Header mode classes.
 *
 * @param string[] $classes Classes.
 * @return string[]
 */
function semrs_pro_body_classes( $classes ) {
	if ( semrs_pro_opt( 'sticky_header' ) ) {
		$classes[] = 'sp-sticky-header';
	}
	if ( is_front_page() && semrs_pro_opt( 'transparent_front' ) ) {
		$classes[] = 'sp-transparent-header';
	}
	return $classes;
}
add_filter( 'body_class', 'semrs_pro_body_classes' );

/**
 * Mega menu: top item with class "semrs-mega" gets 2–4 columns.
 *
 * @param WP_Post[] $items Menu items.
 * @return WP_Post[]
 */
function semrs_pro_mega_classes( $items ) {
	$children = array();
	foreach ( $items as $item ) {
		$p              = (int) $item->menu_item_parent;
		$children[ $p ] = isset( $children[ $p ] ) ? $children[ $p ] + 1 : 1;
	}
	foreach ( $items as $item ) {
		if ( 0 === (int) $item->menu_item_parent && in_array( 'semrs-mega', (array) $item->classes, true ) ) {
			$n               = isset( $children[ (int) $item->ID ] ) ? $children[ (int) $item->ID ] : 0;
			$item->classes[] = 'semrs-mega-cols-' . max( 2, min( 4, (int) ceil( $n / 4 ) ) );
		}
	}
	return $items;
}
add_filter( 'wp_nav_menu_objects', 'semrs_pro_mega_classes' );

/**
 * Main single-post content being rendered?
 *
 * @return bool
 */
function semrs_pro_is_post_content() {
	return is_singular( 'post' ) && in_the_loop() && is_main_query();
}

/**
 * Progress bar markup.
 */
function semrs_pro_progress_bar() {
	if ( is_singular( 'post' ) && semrs_pro_opt( 'progress' ) ) {
		echo '<div class="sp-progress" aria-hidden="true"><span></span></div>';
	}
}
add_action( 'wp_body_open', 'semrs_pro_progress_bar', 5 );

/**
 * Table of contents from H2/H3, with ids added to headings.
 *
 * @param string $content Rendered content.
 * @return string
 */
function semrs_pro_toc( $content ) {
	if ( ! semrs_pro_is_post_content() || ! semrs_pro_opt( 'toc' ) || false !== strpos( $content, 'rank-math-toc' ) || false !== strpos( $content, 'sp-toc' ) ) {
		return $content;
	}
	if ( ! preg_match_all( '/<h([23])([^>]*)>(.*?)<\/h\1>/is', $content, $matches, PREG_SET_ORDER ) || count( $matches ) < 3 ) {
		return $content;
	}
	$used  = array();
	$items = '';
	foreach ( $matches as $m ) {
		$level = (int) $m[1];
		$text  = wp_strip_all_tags( $m[3] );
		if ( preg_match( '/\sid=["\']([^"\']+)["\']/', $m[2], $idm ) ) {
			$id = $idm[1];
		} else {
			$base = sanitize_title( $text );
			$base = '' === $base ? 'section' : $base;
			$id   = $base;
			for ( $n = 2; isset( $used[ $id ] ); $n++ ) {
				$id = $base . '-' . $n;
			}
			$new     = '<h' . $level . $m[2] . ' id="' . esc_attr( $id ) . '">' . $m[3] . '</h' . $level . '>';
			$at      = strpos( $content, $m[0] );
			$content = false === $at ? $content : substr_replace( $content, $new, $at, strlen( $m[0] ) );
		}
		$used[ $id ] = true;
		$items      .= sprintf( '<li class="sp-toc-l%d"><a href="#%s">%s</a></li>', $level, esc_attr( $id ), esc_html( $text ) );
	}
	$toc = '<details class="sp-toc" open><summary>' . esc_html__( 'On this page', 'semrs-pro' ) . '</summary><ol>' . $items . '</ol></details>';
	$pos = strpos( $content, '</p>' );
	return false === $pos ? $toc . $content : substr_replace( $content, '</p>' . $toc, $pos, 4 );
}
add_filter( 'the_content', 'semrs_pro_toc', 20 );

/**
 * "Updated on" line before and author box after post content.
 *
 * @param string $content Content.
 * @return string
 */
function semrs_pro_post_extras( $content ) {
	if ( ! semrs_pro_is_post_content() ) {
		return $content;
	}
	$id     = get_the_ID();
	$before = '';
	$after  = '';
	if ( semrs_pro_opt( 'updated_date' ) && get_the_modified_date( 'U', $id ) > get_the_date( 'U', $id ) + DAY_IN_SECONDS ) {
		$before = sprintf(
			'<p class="sp-updated">%s <time datetime="%s">%s</time></p>',
			esc_html__( 'Updated on', 'semrs-pro' ),
			esc_attr( get_the_modified_date( 'c', $id ) ),
			esc_html( get_the_modified_date( '', $id ) )
		);
	}
	$author = (int) get_post_field( 'post_author', $id );
	if ( semrs_pro_opt( 'author_box' ) && $author && get_the_author_meta( 'display_name', $author ) ) {
		$reviewer = get_post_meta( $id, 'semrs_reviewed_by', true );
		$after    = sprintf(
			'<aside class="sp-author-box" aria-label="%1$s">%2$s<div><p class="sp-author-name">%3$s <a href="%4$s">%5$s</a></p>%6$s%7$s</div></aside>',
			esc_attr__( 'About the author', 'semrs-pro' ),
			get_avatar( $author, 72, '', '', array( 'loading' => 'lazy' ) ),
			esc_html__( 'Written by', 'semrs-pro' ),
			esc_url( get_author_posts_url( $author ) ),
			esc_html( get_the_author_meta( 'display_name', $author ) ),
			wpautop( esc_html( get_the_author_meta( 'description', $author ) ) ),
			$reviewer ? '<p class="sp-reviewer">' . esc_html__( 'Reviewed by', 'semrs-pro' ) . ' ' . esc_html( $reviewer ) . '</p>' : ''
		);
	}
	return $before . $content . $after;
}
add_filter( 'the_content', 'semrs_pro_post_extras', 25 );

/**
 * Related posts (same category) after single posts.
 */
function semrs_pro_related_posts() {
	if ( ! is_singular( 'post' ) || ! semrs_pro_opt( 'related' ) ) {
		return;
	}
	$cats = wp_get_post_categories( get_the_ID() );
	if ( ! $cats ) {
		return;
	}
	$q = new WP_Query(
		array(
			'category__in'           => $cats,
			'post__not_in'           => array( get_the_ID() ),
			'posts_per_page'         => 3,
			'ignore_sticky_posts'    => true,
			'no_found_rows'          => true,
			'update_post_term_cache' => false,
		)
	);
	if ( ! $q->have_posts() ) {
		return;
	}
	echo '<section class="sp-related" aria-labelledby="sp-related-title"><h2 id="sp-related-title">' . esc_html__( 'Related articles', 'semrs-pro' ) . '</h2><div class="sp-posts">';
	while ( $q->have_posts() ) {
		$q->the_post();
		get_template_part( 'template-parts/card', null, array( 'excerpt' => false ) );
	}
	echo '</div></section>';
	wp_reset_postdata();
}
add_action( 'semrs_after_entry', 'semrs_pro_related_posts', 20 );

/**
 * White label: rename the theme in Appearance → Themes.
 *
 * @param array $themes Prepared themes for JS.
 * @return array
 */
function semrs_pro_white_label( $themes ) {
	$name = trim( (string) semrs_pro_opt( 'white_label' ) );
	if ( $name && isset( $themes['semrs'] ) ) {
		$themes['semrs']['name']        = $name;
		$themes['semrs']['author']      = $name;
		$themes['semrs']['authorAndUri'] = esc_html( $name );
	}
	return $themes;
}
add_filter( 'wp_prepare_themes_for_js', 'semrs_pro_white_label' );

require SEMRS_PRO_DIR . 'modules/patterns.php';
