=== SEMRS Core ===
Contributors: semrs
Tags: seo, schema, sitemap, breadcrumbs, meta description
Requires at least: 6.5
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.1.0
License: GPLv2 or later

Free SEO essentials for any WordPress site. SEMRS Pro adds redirects + 404 log, multi-location local SEO, IndexNow, image SEO, an ads manager, site layouts, proof and lead tracking.

== Modules ==

= SEO (SEMRS → SEO, "SEMRS SEO" box in the editor) =
* Titles with templates and variables, meta descriptions (auto from excerpt or content when empty), homepage title/description.
* Robots meta via WordPress's own API: per-post noindex/nofollow, noindex for search, 404, tag/author/date archives (configurable), max-image-preview:large.
* Canonical URLs for posts, pages, archives and paginated pages; custom canonical per post.
* Open Graph + X cards with per-post share image (featured image fallback, site default).
* JSON-LD graph: Organization / LocalBusiness / ProfessionalService / Person (address, area served, social profiles), WebSite with SearchAction, WebPage, BreadcrumbList, BlogPosting/Article/NewsArticle with Person author, Service, WebApplication (free tools), About/Contact/Collection pages, and FAQPage built automatically from visible Details blocks.
* XML sitemap on WordPress's core engine (/wp-sitemap.xml): noindexed posts left out, lastmod dates, tag/author sitemaps follow noindex settings, old /sitemap_index.xml and /sitemap.xml redirect.
* robots.txt extra lines, Google/Bing verification, breadcrumbs (used by SEMRS Pro).
* Editor box: focus keyword, SEO title and description with live counters, Google preview, canonical, schema type, noindex/nofollow, and checks (keyword in title/description/slug/first 100 words, title and description length, 300+ words, internal link, image alt text, single H1).
* Switching from Rank Math: SEMRS output pauses while Rank Math (or Yoast, AIOSEO, SEOPress, The SEO Framework) is active. Rank Math titles, descriptions, focus keywords, canonicals, noindex/nofollow, share images and primary categories are read automatically, so nothing is lost when you switch.

== Changelog ==

= 1.1.0 =
* Automatic update notices from semrs.com (WordPress 'Update available' + one-click update)
* Logo width controls for desktop and mobile; 512×512 square logos detected automatically
* Footer social icons in brand colours (9 networks)
* Free/Pro split: premium modules moved to the SEMRS Pro plugin
* Pro: license status checked with semrs.com

= 1.0.0 =
* Free/Pro split: SEO essentials stay in Core; redirects, ads, layouts, proof and leads moved to SEMRS Pro. Extensible module loader.

= 0.3.0 =
* New SEO module (titles, meta, robots, canonical, social, schema, sitemaps, redirects, 404 log, breadcrumbs, checks, Rank Math compatibility).
* Ads module merged in (formerly the SEMRS Ads plugin).
* Module switches and a SEMRS admin menu.
* Site Layouts now work with SEMRS Pro and Astra.

= 0.2.0 =
* First release.
